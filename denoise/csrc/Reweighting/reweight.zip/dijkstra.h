#ifndef _DIJKSTRA
#define _DIJKSTRA

extern "C" {
  void predict_edge(void *, void *, int, int, void *);
}

#endif

